from __future__ import annotations

import asyncio
import json
from typing import Any

import websockets

from app.collectors.base import BaseCollector
from app.config import get_settings
from app.models import BBOEvent, BookDeltaEvent, LiquidationEvent, MarkIndexEvent, TradeEvent


class BinanceFuturesCollector(BaseCollector):
    """
    Uses Binance's separated routing:
    - /public for high-frequency book feeds
    - /market for aggTrade / markPrice / liquidation
    """

    def __init__(self, bus):
        super().__init__(bus)
        self.settings = get_settings()
        self.symbol = self.settings.symbol.lower()

    async def run(self) -> None:
        await asyncio.gather(
            self.run_public(),
            self.run_market(),
        )

    async def run_public(self) -> None:
        stream = f"{self.symbol}@bookTicker/{self.symbol}@depth@100ms"
        url = f"{self.settings.binance_futures_public_ws}/stream?streams={stream}"
        attempt = 0
        while True:
            try:
                async with websockets.connect(url, ping_interval=20, ping_timeout=20, max_queue=10000) as ws:
                    attempt = 0
                    async for raw in ws:
                        msg = json.loads(raw)
                        stream_name = msg["stream"]
                        data = msg["data"]
                        if stream_name.endswith("@bookTicker"):
                            event = self._parse_bbo(data)
                            await self._emit("raw:bbo:binance_futures:btcusdt", event)
                        elif "@depth" in stream_name:
                            event = self._parse_book_delta(data)
                            await self._emit("raw:book_delta:binance_futures:btcusdt", event)
            except Exception:
                attempt += 1
                await self.sleep_backoff(attempt)

    async def run_market(self) -> None:
        stream = f"{self.symbol}@aggTrade/{self.symbol}@markPrice@1s/!forceOrder@arr"
        url = f"{self.settings.binance_futures_market_ws}/stream?streams={stream}"
        attempt = 0
        while True:
            try:
                async with websockets.connect(url, ping_interval=20, ping_timeout=20, max_queue=10000) as ws:
                    attempt = 0
                    async for raw in ws:
                        msg = json.loads(raw)
                        stream_name = msg["stream"]
                        data = msg["data"]
                        if stream_name.endswith("@aggTrade"):
                            event = self._parse_trade(data)
                            await self._emit("raw:trade:binance_futures:btcusdt", event)
                        elif "@markPrice" in stream_name:
                            event = self._parse_mark_index(data)
                            await self._emit("raw:mark_index:binance_futures:btcusdt", event)
                        elif "forceOrder" in stream_name:
                            event = self._parse_liquidation(data)
                            if event is not None:
                                await self._emit("raw:liquidation:binance_futures:btcusdt", event)
            except Exception:
                attempt += 1
                await self.sleep_backoff(attempt)

    def _parse_trade(self, data: dict[str, Any]) -> TradeEvent:
        # Binance: m=true means buyer is market maker -> taker was seller.
        aggressive_side = "sell" if data["m"] else "buy"
        price = float(data["p"])
        size = float(data["q"])
        return TradeEvent(
            venue="binance_futures",
            symbol=data["s"],
            market_type="perp",
            aggressive_side=aggressive_side,
            price=price,
            size=size,
            notional=price * size,
            trade_id=str(data["a"]),
            ts_exchange=int(data["T"]),
            ts_local=self.now_ms(),
        )

    def _parse_mark_index(self, data: dict[str, Any]) -> MarkIndexEvent:
        mark = float(data["p"])
        index = float(data["i"])
        premium_bps = 10000.0 * (mark - index) / index if index else 0.0
        return MarkIndexEvent(
            venue="binance_futures",
            symbol=data["s"],
            mark_price=mark,
            index_price=index,
            funding_rate=float(data["r"]),
            premium_bps=premium_bps,
            ts_exchange=int(data["E"]),
            ts_local=self.now_ms(),
        )

    def _parse_bbo(self, data: dict[str, Any]) -> BBOEvent:
        bid_px = float(data["b"])
        ask_px = float(data["a"])
        bid_sz = float(data["B"])
        ask_sz = float(data["A"])
        mid = (bid_px + ask_px) / 2.0
        spread_bps = 10000.0 * (ask_px - bid_px) / mid if mid else 0.0
        return BBOEvent(
            venue="binance_futures",
            symbol=data["s"],
            bid_px=bid_px,
            bid_sz=bid_sz,
            ask_px=ask_px,
            ask_sz=ask_sz,
            mid_px=mid,
            spread_bps=spread_bps,
            ts_exchange=int(data["E"]),
            ts_local=self.now_ms(),
        )

    def _parse_book_delta(self, data: dict[str, Any]) -> BookDeltaEvent:
        return BookDeltaEvent(
            venue="binance_futures",
            symbol=data["s"],
            first_update_id=int(data["U"]),
            final_update_id=int(data["u"]),
            prev_final_update_id=int(data["pu"]),
            bids=[[float(px), float(sz)] for px, sz in data.get("b", [])],
            asks=[[float(px), float(sz)] for px, sz in data.get("a", [])],
            ts_exchange=int(data["E"]),
            ts_local=self.now_ms(),
        )

    def _parse_liquidation(self, data: dict[str, Any]) -> LiquidationEvent | None:
        order = data.get("o")
        if not order or order.get("s") != self.symbol.upper():
            return None
        price = float(order["ap"])
        size = float(order["z"])
        return LiquidationEvent(
            venue="binance_futures",
            symbol=order["s"],
            side=order["S"],
            price=price,
            size=size,
            notional=price * size,
            ts_exchange=int(order["T"]),
            ts_local=self.now_ms(),
        )

    async def _emit(self, channel: str, model) -> None:
        payload = model.model_dump()
        await self.bus.publish_json(channel, payload)
        await self.bus.set_json(f"state:latest:{channel}", payload)


async def main() -> None:
    from app.bus import RedisBus

    settings = get_settings()
    bus = RedisBus(settings.redis_url)
    collector = BinanceFuturesCollector(bus)
    await collector.run()


if __name__ == "__main__":
    asyncio.run(main())
