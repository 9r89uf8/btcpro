from __future__ import annotations

import asyncio
import json
from typing import Any

import websockets

from app.collectors.base import BaseCollector
from app.config import get_settings
from app.models import BBOEvent, BookDeltaEvent, TradeEvent


class BinanceSpotCollector(BaseCollector):
    def __init__(self, bus):
        super().__init__(bus)
        self.settings = get_settings()
        self.symbol = self.settings.symbol.lower()

    async def run(self) -> None:
        stream = f"{self.symbol}@aggTrade/{self.symbol}@bookTicker/{self.symbol}@depth@100ms"
        url = f"{self.settings.binance_spot_ws}/stream?streams={stream}"
        attempt = 0
        while True:
            try:
                async with websockets.connect(url, ping_interval=20, ping_timeout=20, max_queue=10000) as ws:
                    attempt = 0
                    async for raw in ws:
                        msg = json.loads(raw)
                        stream_name = msg["stream"]
                        data = msg["data"]
                        if stream_name.endswith("@aggTrade"):
                            event = self._parse_trade(data)
                            await self._emit("raw:trade:binance_spot:btcusdt", event)
                        elif stream_name.endswith("@bookTicker"):
                            event = self._parse_bbo(data)
                            await self._emit("raw:bbo:binance_spot:btcusdt", event)
                        elif "@depth" in stream_name:
                            event = self._parse_book_delta(data)
                            await self._emit("raw:book_delta:binance_spot:btcusdt", event)
            except Exception:
                attempt += 1
                await self.sleep_backoff(attempt)

    def _parse_trade(self, data: dict[str, Any]) -> TradeEvent:
        aggressive_side = "sell" if data["m"] else "buy"
        price = float(data["p"])
        size = float(data["q"])
        return TradeEvent(
            venue="binance_spot",
            symbol=data["s"],
            market_type="spot",
            aggressive_side=aggressive_side,
            price=price,
            size=size,
            notional=price * size,
            trade_id=str(data["a"]),
            ts_exchange=int(data["T"]),
            ts_local=self.now_ms(),
        )

    def _parse_bbo(self, data: dict[str, Any]) -> BBOEvent:
        bid_px = float(data["b"])
        ask_px = float(data["a"])
        bid_sz = float(data["B"])
        ask_sz = float(data["A"])
        mid = (bid_px + ask_px) / 2.0
        spread_bps = 10000.0 * (ask_px - bid_px) / mid if mid else 0.0
        return BBOEvent(
            venue="binance_spot",
            symbol=data["s"],
            bid_px=bid_px,
            bid_sz=bid_sz,
            ask_px=ask_px,
            ask_sz=ask_sz,
            mid_px=mid,
            spread_bps=spread_bps,
            ts_exchange=int(data.get("E", data.get("u", 0))),
            ts_local=self.now_ms(),
        )

    def _parse_book_delta(self, data: dict[str, Any]) -> BookDeltaEvent:
        return BookDeltaEvent(
            venue="binance_spot",
            symbol=data["s"],
            first_update_id=int(data["U"]),
            final_update_id=int(data["u"]),
            prev_final_update_id=int(data.get("pu", 0)) or None,
            bids=[[float(px), float(sz)] for px, sz in data.get("b", [])],
            asks=[[float(px), float(sz)] for px, sz in data.get("a", [])],
            ts_exchange=int(data["E"]),
            ts_local=self.now_ms(),
        )

    async def _emit(self, channel: str, model) -> None:
        payload = model.model_dump()
        await self.bus.publish_json(channel, payload)
        await self.bus.set_json(f"state:latest:{channel}", payload)


async def main() -> None:
    from app.bus import RedisBus

    settings = get_settings()
    bus = RedisBus(settings.redis_url)
    collector = BinanceSpotCollector(bus)
    await collector.run()


if __name__ == "__main__":
    asyncio.run(main())
