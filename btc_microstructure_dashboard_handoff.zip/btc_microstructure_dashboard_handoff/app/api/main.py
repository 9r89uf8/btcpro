from __future__ import annotations

from fastapi import FastAPI, Query

from app.bus import RedisBus
from app.config import get_settings

settings = get_settings()
bus = RedisBus(settings.redis_url)
app = FastAPI(title="BTC Microstructure Dashboard API", version="0.1.0")


@app.get("/health")
async def health() -> dict:
    latest_score = await bus.get_json("state:latest:score:btcusdt")
    latest_features = await bus.get_json("state:latest:feature_bar:btcusdt")
    return {
        "status": "ok",
        "score_available": latest_score is not None,
        "features_available": latest_features is not None,
        "book_sync_ok": bool(latest_features.get("book_sync_ok")) if latest_features else False,
    }


@app.get("/latest/score")
async def latest_score() -> dict:
    return await bus.get_json("state:latest:score:btcusdt") or {}


@app.get("/latest/features")
async def latest_features() -> dict:
    return await bus.get_json("state:latest:feature_bar:btcusdt") or {}


@app.get("/history/features")
async def history_features(minutes: int = Query(default=60, ge=1, le=1440)) -> dict:
    # Placeholder. Replace with ClickHouse/Parquet query in Phase 2.
    return {
        "message": "Not implemented yet",
        "minutes": minutes,
    }


@app.on_event("shutdown")
async def shutdown_event() -> None:
    await bus.close()
