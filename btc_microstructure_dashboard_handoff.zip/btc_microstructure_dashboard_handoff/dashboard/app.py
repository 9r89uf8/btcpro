from __future__ import annotations

import requests
from dash import Dash, Input, Output, dcc, html

API_BASE = "http://localhost:8000"

app = Dash(__name__)
app.layout = html.Div(
    [
        html.H2("BTC 1–5 Minute Microstructure Dashboard"),
        dcc.Interval(id="poll", interval=1000, n_intervals=0),
        html.Div(id="ribbon"),
        html.Pre(id="score"),
        html.Pre(id="features"),
    ],
    style={"fontFamily": "sans-serif", "padding": "20px"},
)


@app.callback(
    Output("ribbon", "children"),
    Output("score", "children"),
    Output("features", "children"),
    Input("poll", "n_intervals"),
)
def refresh(_: int):
    score = requests.get(f"{API_BASE}/latest/score", timeout=2).json()
    features = requests.get(f"{API_BASE}/latest/features", timeout=2).json()

    ribbon = html.Div(
        [
            html.Span(f"State: {score.get('state', '-')}", style={"marginRight": "20px"}),
            html.Span(f"1m: {score.get('score_1m', 0):.3f}", style={"marginRight": "20px"}),
            html.Span(f"3m: {score.get('score_3m', 0):.3f}", style={"marginRight": "20px"}),
            html.Span(f"5m: {score.get('score_5m', 0):.3f}", style={"marginRight": "20px"}),
            html.Span(f"Confidence: {score.get('confidence', 0):.3f}", style={"marginRight": "20px"}),
            html.Span(f"Premium bps: {features.get('premium_bps', 0):.2f}", style={"marginRight": "20px"}),
            html.Span(f"Book sync: {features.get('book_sync_ok', False)}"),
        ]
    )
    return ribbon, str(score), str(features)


if __name__ == "__main__":
    app.run(debug=True, port=8050)
